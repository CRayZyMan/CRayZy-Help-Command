AddEventHandler('chatMessage', function(source, n, message)

    command = stringsplit(message, " ")
	if(command[1] == "/help") then --/Help Command Hast Va mitavanid Avazash Konid 

    CancelEvent()                                               --Matn Ro Dar In Patin Benevisid ↴                   
    TriggerClientEvent("chatMessage", source, n, {255, 0, 0}, "^5 Lotfan Be Dsicord Server Bearvid Va Montazer Admin Bashid Ta ^4 Be Shoma Komak Konad 🌟")
    end
end)

--Be In Bakhsh Dast Nazanid Lotfan ↴

function stringsplit(inputstr, sep)
    if sep == nil then
        sep = "%s"
    end
    local t={} ; i=1
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        t[i] = str
        i = i + 1
    end
    return t
end
